//Interface
public interface DataMahasiswa { 
    public String Tanggal();
    public String Waktu();
    public void NoPeserta();
    public void Nama();
    public void Alamat();
    public void NoHP();
    public String JenisFakultas();
    public void Fakultas();
    public void Rincian();
    public void Jurusan();
    public String JenisBeasiswa();
    public void Beasiswa();
    public void Potongan();
    public void TotalBiaya(); 
}
